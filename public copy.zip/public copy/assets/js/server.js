const express = require('express');
const path = require('path');

const PORT = process.env || 3000;
const app = express();


// GET /notes should return the notes.html file.
app.get('/notes', (req, res) => {
    res.json();
});


// GET * should return the index.html file.


app.listen(PORT, () => console.log(`App listening on PORT ${PORT}`));